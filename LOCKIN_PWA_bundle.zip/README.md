# LOCKIN PWA — setup guide

This folder contains your installable, mobile-friendly LOCKIN study tracker.

## What is included
- `index.html` — app UI and logic
- `manifest.webmanifest` — install name, theme, icons and standalone display
- `sw.js` — service worker for caching the app shell for offline reopening
- `icons/` — 192px and 512px app icons
- `.nojekyll` — makes GitHub Pages publish the static files as-is

## Data storage and backups
- LOCKIN saves data in browser `localStorage` on the same site origin and device.
- It requests persistent storage where supported, but the browser may decline. This is not cloud sync.
- Open **Habits & routine → Backup & restore → Export backup** to download a JSON backup.
- To restore, open the same section and choose **Import backup**. Import replaces the current local data, after confirmation. Export first if you want to preserve the current state.
- Export backups somewhere safe (for example, your own private cloud drive). Do not upload personal backup JSON files into the public website repository.
- Moving from the old `file://` prototype to the hosted HTTPS site creates a different storage origin. Export from the updated old prototype first, then import the JSON backup on the hosted site.

## Publish free with GitHub Pages (beginner-friendly)
1. On GitHub, create a new repository named `lockin-pwa`. If you use GitHub Free, choose **Public** for the repository. The website will be publicly reachable, but your personal tracker data stays in your browser and is not part of the repository unless you upload a backup.
2. On the repository page, choose **Add file → Upload files**.
3. Upload the *contents* of this folder (not just the ZIP): `index.html`, `manifest.webmanifest`, `sw.js`, `.nojekyll`, and the `icons` folder with both PNG files. If the mobile upload flow does not let you upload folders, use GitHub's browser file editor or a computer to create the repository structure.
4. Commit the files to the `main` branch.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, set **Source** to **Deploy from a branch**, select branch `main` and folder `/(root)`, then save.
7. Wait for the deployment to finish. GitHub Pages will show a URL similar to `https://YOUR-USERNAME.github.io/lockin-pwa/`. Use the exact URL shown in Pages.
8. Open that HTTPS URL in Chrome on Android. Wait for the page to load once while online.
9. Tap Chrome's **⋮** menu and choose **Install app** or **Add to Home screen**. The wording varies by device/browser.
10. Open LOCKIN from the home-screen icon. Go to **Habits & routine → Backup & restore** and import your backup if you exported one from the older prototype.

## Updating the app later
Upload the changed site files to the same repository and commit them. The service worker cache version can be updated in `sw.js` (`lockin-pwa-v1` → `lockin-pwa-v2`) when making larger changes, so installed copies refresh their cached app shell.

## Important limitations
- This is local-first storage, not a cloud database. No login or cross-device sync is included.
- Local storage is tied to the hosted origin and can be cleared by browser/device cleanup. Export backups regularly.
- The service worker caches the app shell for offline reopening after the first successful online visit; browser storage and offline cache can still be removed by the operating system.
- GitHub Pages websites are public. Keep personal study data in the app's local storage and keep backup files private.

## Official documentation
- MDN: https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable
- GitHub Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
